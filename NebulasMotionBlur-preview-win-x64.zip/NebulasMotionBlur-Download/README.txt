NEBULA'S MOTION BLUR
Windows x64 preview release

QUICK START
1. Extract this entire ZIP to a folder you can write to.
2. Open NebulasMotionBlur.exe. Keep the other files beside it.
3. On the Cursor tab, select your own osu! skin folder or transparent PNG.
4. Open osu! and check that the blur follows your game cursor accurately.

RUNTIME
This small download does not bundle .NET. If Windows says the required
framework is missing, install the Windows x64 .NET Desktop Runtime from:
https://dotnet.microsoft.com/en-us/download/dotnet/10.0
Choose .NET Desktop Runtime, Windows, x64. The SDK is not needed to play.

CONTROLS
Motion: presets, duration, strength, opacity, path length and decay.
Cursor: image selection, image preview, size and brightness.
Performance: interpolation, sample budget, drawing rate and focus behavior.
Diagnostics: compact in-game HUD and tracking statistics.
Open preview opens a separate local test window.
Save settings writes settings.json beside the executable.
Close the settings window to exit the app.

STARTING POINT
600Hz-like preset, 8 ms duration, 240 Hz draw requests, extra sharp cursor off.
Try Strong to make the effect easier to notice while checking visibility.
The preset names describe visual targets, not measured refresh equivalence.

KNOWN LIMITS
This is an experimental visual overlay, not a display refresh-rate upgrade.
It observes the Windows pointer; raw-relative game input or different game
mapping/sensitivity can prevent alignment with the actual osu! cursor.
Exclusive fullscreen may hide the overlay. Try borderless/windowed instead.
Input checks and draw callbacks are not physical polling rate/display FPS.
Live gameplay alignment, GPU utilization and end-to-end latency have not
been verified by the automated build environment. Test on your own setup.

The program does not modify game files, memory, scoring or driver settings.
This package uses the built-in cursor until you choose your own artwork.
It contains no bundled osu! skin assets or developer test logs.

BUILD VALIDATION
Release compilation: no warnings or errors.
110 algorithm checks passed; settings screens and synthetic HUD rendered.
The desktop-cursor smoke test was restricted by its execution session.

UNINSTALL
Close the app and delete the extracted folder. No installer is used.
